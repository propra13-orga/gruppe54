package propra2013.Gruppe54;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;

import javax.swing.ImageIcon;

public class Spielfigur extends Rectangle {
	Image image;
	private int dx;
	private int dy;
	public int a;
	public int b;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Konstruktor
	 */
	public Spielfigur(int x, int y, int width, int height){
		setBounds(x,y,width,height);
		ImageIcon im = new ImageIcon("pics/spieler2.png");
		image = im.getImage();
		a=0;
		b=192;
		
	}
	

	public Image getImage(){
		return image;
	}

	
	public void draw(Graphics g){
		g.drawImage(image, a, b, width, height, null);
	}
	
	public void move(){
		a= a+dx;
		b= b+dy;
	}
	
	
	public void keyPressed(KeyEvent e){
        int key = e.getKeyCode();
        
         if (key == KeyEvent.VK_A) {
            dx = -1;
         
        }

        if ((key == KeyEvent.VK_D))  {
            dx = 1;
        
        }

        if (key == KeyEvent.VK_W) {
            dy = -1;
        }

        if (key == KeyEvent.VK_S) {
            dy= 1;
        }
	}
   
	

    public void keyReleased(KeyEvent e) {
        int key = e.getKeyCode();

        if (key == KeyEvent.VK_A) {
            dx = 0;
           
        }

        if (key == KeyEvent.VK_D) {
            dx = 0;
        }

        if (key == KeyEvent.VK_W) {
            dy = 0;
        }

        if (key == KeyEvent.VK_S) {
            dy = 0;
        }
    }

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
